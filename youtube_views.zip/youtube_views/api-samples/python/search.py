#!/usr/bin/python

from apiclient.discovery import build
from apiclient.errors import HttpError
from oauth2client.tools import argparser
import json
from datetime import datetime,timedelta
from dateutil.relativedelta import relativedelta

from comment_threads import get_authenticated_service,get_comments

# Set DEVELOPER_KEY to the API key value from the APIs & auth > Registered apps
# tab of
#   https://cloud.google.com/console
# Please ensure that you have enabled the YouTube Data API for your project.
DEVELOPER_KEY = "AIzaSyAwtaXxK4eHiMxbFFsdnFHFtXJ7PhCuGXw"
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"

VIEW_COUNT_RANGE = 10000000

def get_time_delta(time_string):
    '''returns year, month, day from string like 1y_2m_1d'''
    time_list = time_string.split('_')
    delta_list = []
    for d in time_list:
        delta_list.append([int(s) for s in list(d) if s.isdigit()][0])
    return delta_list

def youtube_search(options):
  youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
    developerKey=DEVELOPER_KEY)

  with open('filtered_videos_list.txt','w') as f:
    pass
  options.max_results = int(options.max_results)
  # Call the search.list method to retrieve results matching the specified
  # query term.
  pages = range(options.max_results)
  page_token = None
  options.view_count = int(options.view_count)
  year, month, day = get_time_delta(options.published_ago)
  published_ago = datetime.today() - relativedelta(years= year, months=month,days=day)

  filtered_videos = []
  for page in pages[::50]:
      if page+50 <= options.max_results:
          max_results = 50
      else:
          max_results = options.max_results-page 
      search_response = youtube.search().list(
        q=options.q,
        part="id,snippet",
        maxResults=max_results,
        type='video',
        publishedAfter=published_ago.isoformat('T')+'Z',
        pageToken=page_token
      ).execute()
     
      #videos = []
      #video_ids = []
     
      try:
        page_token = search_response["nextPageToken"]
      except KeyError:
        pass
      yt = get_authenticated_service(args)

      for x, ids in enumerate(search_response["items"]):
        print 'checking video', x+page+1, 'of', options.max_results, 'with keyword', options.q
        video_response = youtube.videos().list(
                         id=ids["id"]["videoId"],
                         part='statistics'
                         ).execute()
        view_count = int(video_response["items"][0]["statistics"]["viewCount"])
        #print view_count, '--view_count', options.view_count 
        
        if view_count >= options.view_count and view_count <= options.view_count+VIEW_COUNT_RANGE:
            try:
               if get_comments(yt, ids["id"]["videoId"], None, int(options.replies)):
                print 'SUCCESS!' 
                filtered_videos.append(ids["id"]["videoId"])
            except HttpError, e:
                print "An HTTP error %d ocurred: /n%s" % (e.resp.status, e.content)

        #    elif search_result["id"]["kind"] == "youtube#channel":
        #      channels.append("%s (%s)" % (search_result["snippet"]["title"],
        #                                   search_result["id"]["channelId"]))
        #    elif search_result["id"]["kind"] == "youtube#playlist":
        #      playlists.append("%s (%s)" % (search_result["snippet"]["title"],
        #                                    search_result["id"]["playlistId"]))
  with open('filtered_videos_list.txt','a') as f:
    for line in filtered_videos:
      f.write('https://www.youtube.com/watch?v='+str(line)+'\n')
  print 'Videos with top comment by video author have been added to filtered_videos_list.txt' 


if __name__ == "__main__":
  argparser.add_argument("--q", help="Search term", default="Google")
  argparser.add_argument("--replies", help="Search term", default=0)
  argparser.add_argument("--max_results", help="Max results", default=5000)
  argparser.add_argument("--published_ago", help="date when published after", default='1y_0m_0d')
  argparser.add_argument("--view_count", help="minimum amount of views, default is 1 million", default=1000000)
  args = argparser.parse_args()

  try:
    youtube_search(args)
  except HttpError, e:
    print "An HTTP error %d occurred:\n%s" % (e.resp.status, e.content)
