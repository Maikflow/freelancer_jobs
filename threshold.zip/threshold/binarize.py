import cv2
import numpy as np
import wave
import os
from time import sleep

def binarize_image(src):
    """
    Recibe una imagen (como matriz), y le aplica 
    el metodo del umbral (en blanco y negro)
    """

    #Convertimos la imagen a escala de grises
    gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)

    #Aplicamos el metodo del umbral, primero para obtener el umbral promedio
    (thresh, threshed_image) = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    #Aplicamos el metodo ahora con el umbral promedio para obtener mejores resultados
    (thresh, threshed_image) = cv2.threshold(gray, thresh, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    #threshed_image = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 11, 2)

    #Mostramos la imagen 
    cv2.imshow('preview',threshed_image)
    cv2.waitKey(2)

    #la guardamos en el actual directorio como 'muestra.jpg'
    cv2.imwrite('muestra.jpg',threshed_image) 
    check_contours(threshed_image, src)
    sleep(2)

def check_contours(threshed_image, img):

    print 'si entra aqui tambien'
    x, contours,hierarchy = cv2.findContours(threshed_image,1,2)
    drawing = np.zeros(img.shape,np.uint8)
    max_area=0
    for i in range(len(contours)):
        cnt=contours[i] 
        area = cv2.contourArea(cnt)
        if(area>max_area):
            max_area=area
            ci=i

    cnt = contours[ci]
    hull = cv2.convexHull(cnt)
    moments = cv2.moments(cnt)
    if moments['m00']!=0:
        print 'si entro!!!'
        cx = int(moments['m10']/moments['m00']) # cx = M10/M00
        cy = int(moments['m01']/moments['m00']) # cy = M01/M00
        centr=(cx,cy)
        cv2.circle(img,centr,5,[0,0,255],2)
        cv2.drawContours(drawing,[cnt],0,(0,255,0),2)
        cv2.drawContours(drawing,[hull],0,(0,0,255),2)
        cnt = cv2.approxPolyDP(cnt,0.01*cv2.arcLength(cnt,True),True)
        hull = cv2.convexHull(cnt,returnPoints = False)
        if(1):
            defects = cv2.convexityDefects(cnt,hull)
            mind=0
            maxd=0
            for i in range(defects.shape[0]):
                s,e,f,d = defects[i,0]
                start = tuple(cnt[s][0])
                end = tuple(cnt[e][0])
                far = tuple(cnt[f][0])
                dist = cv2.pointPolygonTest(cnt,centr,True)
                cv2.line(threshed_image,start,end,[0,255,0],2)
                cv2.circle(threshed_image,far,5,[0,0,255],-1)
                print(i)
                i=0
            cv2.imshow('output',drawing)
            cv2.imshow('input',threshed_image)
            cv2.waitKey(2)


def detect_motion(t0, t1, t2):
    """
    Calcula la diferencia absoluta entre dos pares de imagenes y
    retorna la matriz resultante
    """
    d1 = cv2.absdiff(t2, t1)
    d2 = cv2.absdiff(t1, t0)
    return cv2.bitwise_and(d1, d2)

def choose_song():
    """
    Elige la cancion de acuerdo al gesto obentido en la imagen
    """
    if 1:
        wave.open('Aterciopelados.wav')
    elif 2:
        wave.open('Juanes.wav')
    elif 3:
        wave.open('CHOCQUIBTOWN.wav')

def get_webcam():
    """
    Activa la camara y toma una foto al detectar movimiento 
    en la imagen actual
    """

    #Inicializamos la camara
    vc = cv2.VideoCapture(0)

    #Validamos si la camara se inicializo con exito:
    if vc.isOpened(): 
        #si no hubo error al iniciar, comienza a leer imagenes de la camara
        rval, frame = vc.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        (thresh, threshed_image) = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)

        #Aqui declaramos tres imagenes de referencia
        t_minus = cv2.cvtColor(vc.read()[1], cv2.COLOR_RGB2GRAY)
        t = cv2.cvtColor(vc.read()[1], cv2.COLOR_RGB2GRAY)
        t_plus = cv2.cvtColor(vc.read()[1], cv2.COLOR_RGB2GRAY)
        #Suavizamos la imagen del movimiento y calculamos el promedio 
        #del color de los pixeles
        mean = cv2.GaussianBlur(detect_motion(t_minus, t, t_plus), (5, 5), 0).mean()
    else:
        print "No se encontro una camara web funcional"
        rval = False


    #Mientras la camara este activa:
    while rval:
        gray = cv2.cvtColor(vc.read()[1], cv2.COLOR_BGR2GRAY)
        (thresh, threshed_image) = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)

        img = detect_motion(t_minus, t, t_plus)
       # img = cv2.threshold(img, 128, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
        img = cv2.GaussianBlur(img, (5, 5), 0)

        #Mostrar lo que se esta observando
        cv2.imshow("preview", threshed_image)
        if img.mean()>mean+0.2:
            sleep(3)
            print 'hay movimiento'
            binarize_image(vc.read()[1])
            sleep(3)
            t_minus = cv2.cvtColor(vc.read()[1], cv2.COLOR_RGB2GRAY)
            t = cv2.cvtColor(vc.read()[1], cv2.COLOR_RGB2GRAY)
            t_plus = cv2.cvtColor(vc.read()[1], cv2.COLOR_RGB2GRAY)
            break
        else:
            t_minus = t
            t = t_plus
            t_plus = cv2.cvtColor(vc.read()[1], cv2.COLOR_RGB2GRAY)

        rval, frame = vc.read()
        key = cv2.waitKey(20)
        if key != -1: # exit on anykey 
            break
    cv2.destroyWindow("preview")

if __name__ == "__main__":
    source = 'dosdedos.jpg'
    get_webcam()
